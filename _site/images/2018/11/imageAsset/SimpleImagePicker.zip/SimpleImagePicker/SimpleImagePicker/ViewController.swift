//
//  ViewController.swift
//  SimpleImagePicker
//
//  Created by Gwanho Kim on 01/12/2018.
//  Copyright © 2018 Gwanho Kim. All rights reserved.
//

import UIKit
import Photos

typealias AssetCollection = (collection: PHAssetCollection, count: Int)

class ViewController: UIViewController {
    
    deinit {
        PHPhotoLibrary.shared().unregisterChangeObserver(self)
    }
    
    @IBOutlet private weak var collectionView: UICollectionView!
    
    private var assets = [PHAsset]()
    private var assetCollectionArray = [AssetCollection]()
    private var assetCollectionIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        PHPhotoLibrary.shared().register(self)
        
        self.collectionView.register(PictureCell.self, forCellWithReuseIdentifier: PictureCell.identifier)
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
        if PHPhotoLibrary.authorizationStatus() == .authorized {
            self.collectionFetchData()
        } else if PHPhotoLibrary.authorizationStatus() == .denied {
            print("Permission Denied")
        } else {
            PHPhotoLibrary.requestAuthorization() { (status) in
                switch status {
                case .authorized:
                    self.collectionFetchData()
                    break
                default:
                    print("Permission Denied")
                }
            }
        }
    }
    
    private func collectionFetchData() {
        DispatchQueue.global().async {
            var assetCollectionArray = [AssetCollection]()
            PHAssetCollection.fetchAssetCollections(with: PHAssetCollectionType.smartAlbum, subtype: PHAssetCollectionSubtype.any, options: PHFetchOptions()).enumerateObjects { (collection, _, _) in
                let count = PHAsset.fetchAssets(in: collection, options: nil).count
                if count != 0 {
                    if collection.assetCollectionSubtype == PHAssetCollectionSubtype.smartAlbumUserLibrary {
                        assetCollectionArray.insert((collection, count), at: 0)
                    } else {
                        assetCollectionArray.append((collection, count))
                    }
                }
            }
            self.assetCollectionIndex = 0
            self.assetCollectionArray = assetCollectionArray
            self.albumFetchData()
        }
    }
    
    private func albumFetchData() {
        var assets = [PHAsset]()
        PHAsset.fetchAssets(in: self.assetCollectionArray[self.assetCollectionIndex].0, options: PHFetchOptions()).enumerateObjects({ (asset, _, _) in
            assets.append(asset)
        })
        DispatchQueue.main.async {
            self.assets = assets
            self.collectionView.reloadData()
        }
    }
}

// MARK: PHPhotoLibraryChangeObserver
extension ViewController: PHPhotoLibraryChangeObserver {
    func photoLibraryDidChange(_ changeInstance: PHChange) {
        var assets = [PHAsset]()
        PHAsset.fetchAssets(in: self.assetCollectionArray[self.assetCollectionIndex].0, options: PHFetchOptions()).enumerateObjects({ (asset, _, _) in
            assets.append(asset)
        })
        DispatchQueue.main.async {
            self.assets = assets
            self.collectionView.reloadData()
        }
    }
}


// MARK: UICollectionViewDelegate
extension ViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let asset = self.assets[indexPath.row]
        if let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PictureViewController") as? PictureViewController{
            viewController.asset = asset
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
}

// MARK: UICollectionViewDataSource
extension ViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.assets.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PictureCell.identifier, for: indexPath) as? PictureCell else { fatalError() }
        
        let imageRequestOptions = PHImageRequestOptions()
        imageRequestOptions.isSynchronous = true
        imageRequestOptions.resizeMode = .fast
        imageRequestOptions.isNetworkAccessAllowed = true
        imageRequestOptions.deliveryMode = .highQualityFormat
        
        let size = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width)
        PHCachingImageManager().requestImage(for: self.assets[indexPath.row], targetSize: size, contentMode: .aspectFit, options: imageRequestOptions, resultHandler: { (image, _) in
            cell.image = image
        })
        
        return cell
    }
}

// MARK: UICollectionViewDelegateFlowLayout
extension ViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: UIScreen.main.bounds.width/3, height: UIScreen.main.bounds.width/3)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
