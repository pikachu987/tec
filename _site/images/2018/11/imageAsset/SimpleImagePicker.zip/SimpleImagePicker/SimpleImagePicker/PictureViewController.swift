//
//  PictureViewController.swift
//  SimpleImagePicker
//
//  Created by Gwanho Kim on 01/12/2018.
//  Copyright © 2018 Gwanho Kim. All rights reserved.
//

import UIKit
import Photos

class PictureViewController: UIViewController {
    var asset: PHAsset?
    
    @IBOutlet private weak var imageView: UIImageView!
    @IBOutlet private weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet private weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.clipsToBounds = true
        self.imageView.contentMode = .scaleAspectFit
        
        self.activityIndicatorView.startAnimating()
        self.activityIndicatorView.style = .gray
        self.label.text = nil
        self.label.textColor = .black
        
        guard let asset = self.asset else { return }
        
        DispatchQueue.global().async {
            let imageRequestOptions = PHImageRequestOptions()
            imageRequestOptions.isSynchronous = true
            imageRequestOptions.deliveryMode = .highQualityFormat
            imageRequestOptions.isNetworkAccessAllowed = true
            imageRequestOptions.progressHandler = { (progress, error, stop, info) in
                DispatchQueue.main.async {
                    self.label.text = String(format: "%.1f", progress*100).appending("%")
                }
            }
            PHCachingImageManager().requestImage(for: asset, targetSize: PHImageManagerMaximumSize, contentMode: .aspectFit, options: imageRequestOptions, resultHandler: { (image, _) in
                DispatchQueue.main.async {
                    self.imageView.image = image
                    self.activityIndicatorView.isHidden = true
                    self.label.isHidden = true
                }
            })
        }
    }
}

